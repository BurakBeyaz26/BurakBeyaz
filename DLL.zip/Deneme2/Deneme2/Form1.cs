﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Deneme2
{
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UInt32 deviceSerialNo = 15; //:D :D olcak mı böye? ne döndürüyor bakalım bi , yanlış değerlere ne gönderiyor anlamadım
                                        //DWORD UInt32 olmaya bili,r bi denmek lazım
            UInt32 password = 3311;
            UInt32 ip = 756;
            UInt16 port = 943;

            //int deneme = SDK_Deneme.__Set_Advanced_Mode();
            int deneme = SDK_Deneme.__Device_Properties(deviceSerialNo,  password,  ip,  port);
            //__Get_Error_Message(int result, char * message)

            label1.Text = deneme.ToString();
            SDK_Deneme.__Show_Error_Message(deneme);


            //değer almayan bişey yok mu ya
            
        }
    }
}
