﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Runtime.InteropServices;


namespace Deneme2
{
    public class SDK_Deneme
    {

        [DllImport("..\\_RC_UTIL.dll")] //.exenin bir üst dosyası anlamına gelir.
        public static extern Int32 __Get_SDK_Version();

        [DllImport("_RC_UTIL.dll")]
        public static extern Int32 __Set_Advanced_Mode();

        [DllImport("_RC_UTIL.dll")]
        public static extern Int32 __Device_Properties(UInt32 deviceSerialNo, UInt32 password, UInt32 ip, UInt16 port);

        [DllImport("_RC_UTIL.dll")]   // .exe nin olduğu dosya dizini anlamına gelir.
        public static extern void __Show_Error_Message(int result);
    }
}
