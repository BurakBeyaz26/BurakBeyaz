﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Runtime.InteropServices;
namespace UdpListener
{
    unsafe public class Cihaz
    {

        [global::System.AttributeUsage(AttributeTargets.Field, AllowMultiple = false)]
        sealed class BitfieldLengthAttribute : Attribute
        {
            UInt32 length;

            public BitfieldLengthAttribute(UInt32 length)
            {
                this.length = length;
            }

            public UInt32 Length { get { return length; } }
        }

        public struct _H_deviceRecord
        {
            public Int32 cardCode;

            public Int16 date;

            public Int16 group1;
            /*
                            [BitfieldLength(11)]
                            public byte hourMin;
                            [BitfieldLength(3)]
                            public byte recordType; // 0:normal   1:deny   2:credit  4:event
                            [BitfieldLength(1)]
                            public byte res1;
                            [BitfieldLength(1)]
                            public byte usedAboneCredit;
            */

            public Int32 group2;
            /*
                            [BitfieldLength(6)]
                            public byte second;
                            [BitfieldLength(2)]
                            public byte appIndex;

                            [BitfieldLength(9)]
                            public byte accessCode;
                            [BitfieldLength(1)]
                            public byte usedBonus;
                            [BitfieldLength(6)]
                            public byte bonus_Ratio_Low6;

                            [BitfieldLength(4)]
                            public byte quantity;
                            [BitfieldLength(4)]
                            public byte bonus_Ratio_High4;
             */
            public Int32 price;
            // 24 userCredit
            // 5 msgCode
            // 3 reserved (32: kullanilmiyor, 64: role cekildi, 128: gecis dogrulandi)

        }

        public struct _error // 8 bits, 6 used, bit order is given below
        {
            byte error;
            /*
                1: memoryFull
                2: extEpromError
                3: intEpromError
                4: rtcError
                5: romError
                6: batteryEmpty
                7: not used
                8: not used
             */
        }

        public struct _otomatStatus // 8 bits, 4 used, bit order is given below
        {
            byte otomatStatus;
            /*
                1: sent
                2: received
                3: tickedReduced
                4: tickedFinished
                5: not used
                6: not used
                7: not used
                8: not used
            */
        }

        unsafe public struct _H_status // 32 bytes
        {
            public byte day;
            public byte month;
            public byte year;
            public byte hour;
            public byte minute;
            public byte second;

            _error error;

            public byte state; // cihazin bulundugu durum, 7 ise kart okuma modunda

            public UInt32 recordCount;

            public UInt32 status; //32 bits, bit order given below
                                  /*
                                       1: relay0
                                       2: relay1
                                       3: relay2
                                       4: relay3
                                       5: cardOperationCont
                                       6: newCard
                                       7: taskEnabl
                                       8: relaxMode

                                       9: redLed
                                      10: greenLed
                                      11: blueLed
                                      12: accessValue
                                      13: accessReady
                                      14: not used
                                      15: not used
                                      16: not used

                                      17: input0
                                      18: input1
                                      19: not used
                                      20: not used
                                      21: not used
                                      22: not used
                                      23: cardWriteOperation
                                      24: cardWriteResult

                                      25: battery
                                      26: battery
                                      27: battery
                                      28: battery
                                      29: registerMode
                                      30: menuMode
                                      31: deviceNotWorkingTime
                                      32: lastPowerType
                                  */
            public UInt32 cardCode;
            UInt16 accessCode;
            byte appIndex;
            byte cardMsgNo;
            byte inOut;
            UInt32 totalCredit;

            //fixed _otomatStatus otomatStatus[2];
            // hack hack hack
            fixed byte otomatStatus[2];
        }

        private struct _H_deviceWorkTime // byte size = 4
        {
            UInt32 time;
            /*
             * 11 bits start
             *  4 bits reserved1
             *  1 bit  disable
             *  
             * 11 bits end
             * 2  bits appIndex
             * 3  bits reserved2
             */
        }

        private struct _H_rs232_2_set // byte size = 1
        {
            byte set;
            /*
             * 2 bits parity2
             * 3 bits baudrateIndex2
             * 3 bits ?
             */
        }

        private struct _H_prnBlock // byte size = 4
        {
            byte set1;
            /*
             * 2 bits connectionType
             * 4 bits totalBarcodeCC
             * 2 bits copy
             */
            byte set2;
            /*
             *   4 bits lengthForCardCode
             *   2 bits parity1
             *   2 bits baudrateIndex1
             */
            byte pageWidth;
            byte spaceCharForCardCode;
        }

        private struct _H_expOptions // byte size = 4
        {
            byte CC;
            /*
             * 4 bits startCC
             * 4 bits endCC
             */
            byte set1;
            /*
             * 1 bit sendFirmName
             * 1 bit sendDateTime
             * 1 bit sendDateTimeWithBarcode
             * 1 bit sendName
             * 1 bit sendCardCode
             * 1 bit sendCardCodeWithBarcode
             * 1 bit sendEntryName
             * 1 bit sendEntryCredit
             */

            byte set2;
            /* 1 bit sendUsedCredit
             * 1 bit sendUsedCreditWithBarcode
             * 1 bit sendRemainCredit
             * 1 bit sendRemainCreditWithBarcode
             * 1 bit sendCounter
             * 1 bit sendCounterWithBarcode
             * 1 bit sendBonus
             * 1 bit useEndLineChar
             */
            byte endLineChar;
        }

        public struct _H_ethernetSET // byte site = 64
        {
            UInt32 deviceIP;
            UInt32 myMask;
            UInt32 myGateway;
            UInt32 devicePORT;
            UInt32 primaryDNSServer;
            UInt32 secondaryDNSServer;
            UInt32 defaultIPAddr;
            UInt32 defaultMask;
            UInt32 serverIP;
            UInt16 serverPORT;
            fixed byte MAC[6];
            fixed byte netBIOSName[16];

            byte set1;
            /* 
             * 5 bits reserved
             * 1 bit  sendIP
             * 1 bit DHCP
             * 1 bit bInConfigMode
             */

            fixed byte Reserved01[5];
        }

        public struct _H_config // 1024 bytes
        {
            fixed byte reservedSystem[64];        //  0

            UInt16 defaultAccessCode;             // 64
            UInt16 f1AccessCode;                  // 66
            UInt16 f2AccessCode;                  // 68
            UInt16 f3AccessCode;                  // 70
            UInt16 f4AccessCode;                  // 72
            UInt16 keyEnabled;                    // 74
                                                  /*
                                                   * 1 bits n0
                                                   * 1 bits n1
                                                   * 1 bits n2
                                                   * 1 bits n3
                                                   * 1 bits n4
                                                   * 1 bits n5
                                                   * 1 bits n6
                                                   * 1 bits n7
                                                   * 1 bits n8
                                                   * 1 bits n9
                                                   * 1 bits bs
                                                   * 1 bits rt
                                                   * 1 bits f1
                                                   * 1 bits f2
                                                   * 1 bits f3
                                                   * 1 bits f4
                                                   */

            UInt16 systemCFG3;                    // 76
                                                  /*
                                                   * 1 bit udpTrigger_if_PowerChanged
                                                   * 1 bit udpTrigger_if_InputChanged
                                                   * 1 bit udpTrigger_if_RelayChanged
                                                   * 1 bit udpTrigger_if_UDPreceived
                                                   * 1 bit ctrlAboneAccess
                                                   * 1 bit udpTrigger_if_RS232sended
                                                   * 
                                                   * 1 bit saveLog_if_PowerChanged
                                                   * 1 bit saveLog_if_InputChanged
                                                   * 1 bit saveLog_if_RelayChanged
                                                   * 1 bit saveLog_if_UDPreceived
                                                   * 1 bit saveLog_if_RS232received
                                                   * 1 bit saveLog_if_RS232sended
                                                   * 
                                                   * 1 bit ctrlAboneDOW
                                                   * 1 bit letWorkingTimeWithCard
                                                   * 1 bit showSessionRecordCount
                                                   * 1 bit showTimeWithSmallFont
                                                   */
            byte cardGroup;                       // 78
            byte serialTimeout;                   // 79
            byte messageTimeout;                  // 80
            byte keyboardTimeout;                 // 81
            byte cardTimeout;                     // 82
            byte relayTimeout;                    // 83
            byte g1Timeout;                       // 84
            byte g2Timeout;                       // 85

            Int16 dayLightStart;                  // 86
            Int16 dayLightEnd;                    // 88
            Int16 personelWorkTolerance;          // 90

            Int32 systemCFG;                      // 92

            /*
             * 1 bit deviceWorkingMode
             * 1 bit waitEntryCode
             * 1 bit waitPassword
             * 1 bit letMultipleSelect
             * 1 bit writeAllowedRecord
             * 1 bit writeDennyRecord
             * 1 bit useBuzzer
             * 1 bit workServerMode
             * 1 bit ctrlWorkingTime
             * 1 bit ctrlExpireDate
             * 1 bit ctrlCredit
             * 1 bit ctrlDirection
             * 1 bit ctrlUseLimit
             * 1 bit writeLastTime
             * 1 bit useCreditMultipler
             * 1 bit dayLightControl
             * 
             * 1 bit showPersonelName
             * 1 bit showCardCode
             * 1 bit showWorkingTime
             * 1 bit showCredit
             * 1 bit showUsedCredit
             * 1 bit showExpireDate
             * 1 bit showCardGroup
             * 1 bit showBonus
             * 
             * 1 bit dontReadIfG1set
             * 1 bit exportInf0_if_G2set
             * 1 bit exportInf0_if_KeyPressed
             * 1 bit exportInf1
             * 1 bit exportInf2
             * 1 bit dontReadAgainUntilG1change
             * 1 bit letBonusUsage
             * 1 bit setRelay_if_G2set
             */

            Int32 systemCFG2;                     // 96
                                                  /*
                                                   * 2 bits accessControl
                                                   * 2 bits closeLCDbackLight
                                                   * 1 bit  closeKeyboardLight
                                                   * 2 bits old_appIndex
                                                   * 1 bit  accessEmulation
                                                   * 
                                                   * 3 bits bonusMultipler
                                                   * 1 bit  showCreditWithBigFont
                                                   * 1 bit  useAboneData
                                                   * 1 bit  readOnlyMode
                                                   * 2 bits proximityByte
                                                   * 
                                                   * 1 bit  ____gprs:1;
                                                   * 1 bit  getCardFromExtEthernet
                                                   * 1 bit  getCardFromExtRS232
                                                   * 1 bit  forwardToEthernet
                                                   * 1 bit  forwardToRS232
                                                   * 1 bit  printWhenUDPreceived
                                                   * 1 bit  printUDPbuffer
                                                   * 1 bit  printUDPbufferWithBarcode
                                                   * 
                                                   * 1 bit  printTicket
                                                   * 2 bits clearPrinterCounter
                                                   * 1 bit  udpTrigger_if_G2set
                                                   * 1 bit  udpTrigger_if_KeyPressed
                                                   * 1 bit  udpTrigger_if_CardDetected
                                                   * 1 bit  use1aDayCreditMultipler
                                                   * 1 bit  use1aDayAboneData
                                                   * 1 bit  setRelay_if_G1set
                                                   */

            //fixed _H_deviceWorkTime deviceWorkTime[6]; //100
            //hack 
            fixed UInt32 deviceWorkTime[6];       //100

            byte sameCardTime;                    //124
            byte cardBlokeTime;                   //125
            byte summerClockHour;                 //126

            _H_rs232_2_set rs232_2_set;           //127

            // second 128
            _H_prnBlock prnBlock;                 //128


            //fixed _H_expOptions expOptions[3];  //132
            // hack hack hack
            fixed UInt64 expOptions[3];           //132

            UInt16 prnCounter;                    //144
            UInt16 counterDate;                   //146 only hardware

            UInt16 externalDevicePort;            //148
            UInt32 externalDeviceIP;              //150

            fixed byte firmDesc1[33];             //154
            fixed byte firmDesc2[33];             //187

            // 3 x 12
            fixed byte prnContChar[36];           //220

            // 256 byte end
            _H_ethernetSET ethernetSET;           //256

            // reserved for future
            UInt32 manuelWorkingTime_;            //320
            fixed byte reservedFuture_[76];       //324
        }

        public static byte avesBlockNo = 60;

        public static UInt16 AvesEncodeDate(byte day, byte month, byte year)
        {
            int date;
            UInt16[] days = new UInt16[13] { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 399 };

            date = ((year + 3) >> 2) + 365 * year + days[month - 1] + day;
            if ((month > 2) && ((year & 0x03) == 0))
                date++;

            return (UInt16)date;
        }

       
        
        [DllImport("C:\\_RC_UTIL.dll")]
        internal static extern Int32 __Beep(UInt32 deviceSerialNo, UInt32 password, UInt32 ip, UInt16 port, byte times, byte duration);
        [DllImport("C:\\_RC_UTIL.dll")]
        internal static extern Int32 __Get_Status(UInt32 deviceSerialNo, UInt32 password, UInt32 ip, UInt16 port, bool task, _H_status* status);


        [DllImport("C:\\_RC_UTIL.dll")]
        internal static extern Int32 __Get_Config(UInt32 deviceSerialNo, UInt32 password, UInt32 ip, UInt16 port, UInt16 start, UInt16 len, byte* data);    //burak
        [DllImport("C:\\_RC_UTIL.dll")]
        internal static extern Int32 __Device_Properties(UInt32 deviceSerialNo, UInt32 password, UInt32 ip, UInt16 port);
    }
}   
