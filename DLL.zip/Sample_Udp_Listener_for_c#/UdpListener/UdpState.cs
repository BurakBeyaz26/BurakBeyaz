﻿using System;
using System.Net.Sockets;
using System.Net;

namespace UdpListener
{
    internal class UdpState
    {
        internal UdpState(UdpClient c, IPEndPoint e)
        {
            this.c = c;
            this.e = e;
        }

        internal UdpClient c;
        internal IPEndPoint e;
    }
}
