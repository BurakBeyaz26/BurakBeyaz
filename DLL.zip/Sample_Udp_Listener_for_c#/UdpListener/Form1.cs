﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;

namespace UdpListener
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox2.Text = "7500";
        }

        string dsn, port, pass, ip;
        private void button1_Click(object sender, EventArgs e)
        {
            dsn = textBox1.Text; port = textBox2.Text; pass = textBox3.Text; ip = textBox4.Text;
            if (dsn.Trim() != "" && port.Trim() != "" && pass.Trim() != "" && ip.Trim() != "")
            {
                button1.Enabled = false;
                //Thread thread = new Thread(getStatus);
                //if (!thread.IsAlive) thread.Start();

                int localPort = Convert.ToInt32(port);
                IPEndPoint remoteSender = new IPEndPoint(IPAddress.Any, 0);
                UdpClient client = new UdpClient(localPort);
                UdpState state = new UdpState(client, remoteSender);
                client.BeginReceive(new AsyncCallback(DataReceived), state);
            }
            else MessageBox.Show("Bütün alanları doldurunuz!", "HATA", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        unsafe public void getStatus()
        {
            UInt32 deviceSerialNo = Convert.ToUInt32(dsn);
            UInt32 password = Convert.ToUInt32(pass);
            UInt32 IP = convertIPtoHex(ip);
            while (true)
            {
                Cihaz._H_status status;
                int deviceStatus = Cihaz.__Get_Status(deviceSerialNo, password, IP, 5522, false,&status);
                if (deviceStatus == 0)
                {
                    LabelYaz(label6, "Cihaza Ulaşılıyor.", Color.LightGreen); 
                    if(status.state == 7) { LabelYaz(label9,"Okuma Modunda.",Color.LightGreen); }
                    else { LabelYaz(label9,"Okuma Modunda Değil.",Color.Firebrick); }
                    LabelYaz(label8, "Son Ulaşım Zamanı : "+ getDeviceTime(status.day, status.month, status.year, status.hour, status.minute, status.second).ToString(),Color.Black);
                }
                else { LabelYaz(label6, "Cihaza Ulaşılamıyor.", Color.Firebrick); LabelYaz(label9, "", Color.Firebrick); }
                Thread.Sleep(20000);
            }
        }

        public void DataReceived(IAsyncResult ar)
        {
            UInt32 deviceSerialNo = Convert.ToUInt32(dsn);
            UInt32 password = Convert.ToUInt32(pass);
            UInt32 IP = convertIPtoHex(ip);


            UdpClient c = (UdpClient)((UdpState)ar.AsyncState).c;
            
            IPEndPoint wantedIpEndPoint = (IPEndPoint)((UdpState)(ar.AsyncState)).e;
            IPEndPoint receivedIpEndPoint = new IPEndPoint(IPAddress.Any, 0);
            Byte[] receiveBytes = c.EndReceive(ar, ref receivedIpEndPoint);
            
            bool isRightHost = (wantedIpEndPoint.Address.Equals(receivedIpEndPoint.Address)) || wantedIpEndPoint.Address.Equals(IPAddress.Any);
            bool isRightPort = (wantedIpEndPoint.Port == receivedIpEndPoint.Port) || wantedIpEndPoint.Port == 0;
            if (isRightHost && isRightPort)
            {
                // Convert data to ASCII and print in console
                //  string receivedText = ASCIIEncoding.ASCII.GetString(receiveBytes);
                string receivedText = System.Text.Encoding.UTF8.GetString(receiveBytes);
                //int readerSerialNo = BitConverter.ToInt32(receiveBytes, 0);
                //int card_id = BitConverter.ToInt32(receiveBytes, 4);
                string strBuf =System.Text.Encoding.ASCII.GetString(receiveBytes).Replace("\r", string.Empty);
                LabelYaz(result, strBuf.ToString(), Color.Black);
                //int a = Cihaz.__Beep(deviceSerialNo, password, IP, 5522, 1, 100);
            }
            
            c.BeginReceive(new AsyncCallback(DataReceived), ar.AsyncState);

        }
        static UInt32 convertIPtoHex(string IP)
        {
            byte[] byt = IPAddress.Parse(IP.Trim()).GetAddressBytes();
            int asd = BitConverter.ToInt32(byt, 0);
            return (uint)BitConverter.ToInt32(byt, 0);


        }
        public DateTime getDeviceTime(byte day, byte month, byte year, byte hour, byte minute, byte second)
        {
            return new DateTime(2000 + year, month, day, hour, minute, second);
        }
        public void LabelYaz(Label x, string txt, Color c)
        {
            x.Invoke(new Action(() => { x.Text = txt; x.ForeColor = c; }));
        }
    }
}
