#include <QCoreApplication>
#include "deneme.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    test();
    //iptodecimal("172.16.40.105");


    return a.exec();

}

