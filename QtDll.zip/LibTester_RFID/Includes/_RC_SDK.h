#ifndef _RC_SDK
#define _RC_SDK
#include "Includes/__DLL_IMPORT.h"


union _error
{ BYTE byte;
  struct
  { BYTE memoryFull:1;
    BYTE extEpromError:1;
    BYTE intEpromError:1;
    BYTE rtcError:1;
    BYTE romError:1;
    BYTE batteryEmpty:1;

    BYTE :1;
    BYTE :1;
  };
};

union _otomatStatus
{ BYTE byte;
  struct
  { BYTE sended:1;
    BYTE received:1;
    BYTE tickedReduced:1;
    BYTE tickedFinished:1;
    BYTE :1;
    BYTE :1;
    BYTE :1;
    BYTE :1;
  };
};


struct _H_status
{
  union { BYTE     block[32];
          struct
          {
            BYTE  day;
            BYTE  month;
            BYTE  year;
            BYTE  hour;
            BYTE  minute;
            BYTE  second;

            _error error;

            BYTE  state;

            int   recordCount;

            union { DWORD status;
                    struct
                    { BYTE relay0:1;
                      BYTE relay1:1;
                      BYTE relay2:1;
                      BYTE relay3:1;
                      BYTE cardOperationCont:1;
                      BYTE newCard:1;
                      BYTE taskEnable:1;
                      BYTE relaxMode:1;

                      BYTE redLed:1;
                      BYTE greenLed:1;
                      BYTE blueLed:1;
                      BYTE accessValue:1;
                      BYTE accessReady:1;
                      BYTE :1;
                      BYTE :1;
                      BYTE :1;

                      BYTE input0:1;
                      BYTE input1:1;
                      BYTE :1;
                      BYTE :1;
                      BYTE :1;
                      BYTE :1;
                      BYTE cardWriteOperation:1;
                      BYTE cardWriteResult:1;

                      BYTE battery:4;
                      BYTE registerMode:1;
                      BYTE menuMode:1;
                      BYTE deviceNotWorkingTime:1;
                      BYTE lastPowerType:1;
                    };
                  };

            int   cardCode;
            WORD  accessCode;
            BYTE  appIndex;
            BYTE  cardMsgNo;
            BYTE  inOut;
            int   totalCredit;

            _otomatStatus otomatStatus[3];
          };
        };
};



struct _H_deviceRecord16
{
  union { BYTE byte_[16];

          struct
          { int   cardCode;

            SHORT date;

            WORD  hourMin:11;
            WORD  recordType:3; // 0:normal   1:denny   2:credit  4:event
            WORD  res1:1;
            WORD  usedAboneCredit:1;

            BYTE  second:6;
            BYTE  appIndex:2;

            WORD  accessCode:9;
            WORD  usedBonus:1;
            WORD  bonus_Ratio_Low6:6;

            BYTE  quantity:4;
            BYTE  bonus_Ratio_High4:4;

            int   price;
          };
        };
};



struct _H_lastAccess_MF // size=12
{ WORD  lastUsedHourMin:11;
  WORD  in:1;
  WORD  :4;

  SHORT lastUsedDate;

  WORD  wStart:11;
  WORD  limitCnt:3;
  WORD  :2;

  WORD  wEnd:11;
  WORD  limitMax:3;
  WORD  :2;

  WORD  expireDate;

  WORD  aboneCredit; // added ver3.35
};





struct _H_cardData_MC // size=96
{
  int  cardCode;
  
  int  credit;
  int  minCredit;

  WORD CRC_UID;
  WORD endUserCode;
  WORD password;

  BYTE groupCode;

  BYTE cardType:2;
  BYTE disabled:1;
  BYTE outOfCtrlDirection:1;
  BYTE bonusUsage:2;
  BYTE creditUsed:1; // only hardware
  BYTE aboneUsed:1;  // only hardware

  char name[16];

  struct _H_lastAccess_MF appData[4];

  BYTE creditMultipler;
  BYTE bonusRatio;

  WORD taskUID;

  int  bonus;

  union { WORD  ticketCounter; // bu alan genel olarak kullanilabilir;
          struct
          { BYTE   sres1;
            BYTE   sres2;
            BYTE   sres3;

            BYTE   resbits:7;
            BYTE   openDevice:1;
          };
        };
};



#endif


