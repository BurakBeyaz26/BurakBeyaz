#ifndef _rc_system_errors_
#define _rc_system_errors_

// hardware constant defines start
#define _success                             0

#define _card_can_not_read                  -1
#define _not_aves_card                      -2
#define _invalid_project_code               -3
#define _invalid_crc_data                   -4
#define _invalid_card_group_code            -5
#define _invalid_firm_code                  -6
// hardware constant defines end

#define _card_not_formatted                -39

#define _read_card                         -40
#define _card_can_not_write                -41
#define _cfg_page_read_error               -42
#define _cfg_page_write_error              -43
#define _unsupported_device_model          -44
#define _device_bussy                      -45
#define _ss_crc_error                      -46
#define _no_device_connection              -50

#define _no_enough_credit                  -75
#define _no_credit_licance                 -80

#define _file_can_not_create               -90
#define _file_not_found                    -91
#define _file_can_not_open                 -92
#define _file_size_not_correct             -93

#define _memory_error                     -100
#define _invalid_pointer                  -101
#define _buffer_not_enough                -102
#define _no_record                        -103

#define _advanced_mode_not_active         -110
#define _service_not_compatible           -111

#define _cancelled                        -150
#define _approved                         -151

#define _input_error                      -155
#define _already_exist                    -156

#define _cfg_file_not_found               -200
#define _no_sql_connection                -201
#define _notRC2XXdatabase                 -202
#define _programOldVersion                -203
#define _invalidServerName                -204
#define _user_not_admin                   -205

#define _table_not_found                  -210
#define _item_not_found                   -211
#define _database_cfg_not_found           -212
#define _computer_not_found               -213
#define _person_not_found                 -215
#define _location_not_found               -216
#define _local_device_not_found           -217
#define _sql_error                        -218
#define _free_card_code_error             -219
#define _tag_not_found                    -220
#define _print_design_not_found           -221
#define _has_more_tags                    -222

#define _login_failed                     -250
#define _login_id_not_correct             -251
#define _user_blocked                     -252

#define _no_permission                    -255

#define _illegal_use_detected             -260

#define _multi_format_permission_error    -300
#define _same_tag                         -301
#define _card_UID_conflict                -302
#define _rc_tag_code_conflict             -303
#define _rc_tag_code_emulation_conflict   -304
#define _no_card_owner                    -305
#define _can_not_use_visitor_card         -306
#define _card_not_in_use                  -307
#define _no_card_permission               -308
#define _card_validity_expired            -309
#define _not_person_card                  -310
#define _not_target_card                  -311
#define _visitor_person                   -312

#define _hd_write_permission_error        -314
#define _not_same_tag                     -315

#define _can_not_change_tag_status        -381
#define _can_not_change_department        -382

#define _service_not_connected            -400

#define _invalid_ticket_data              -800

#define _invalid_parameter                -970
#define _timeout_error                    -980

#define _unknown_error                    -990



void GetErrorMessage(int result, char *message);

#endif


