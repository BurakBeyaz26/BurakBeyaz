#include "deneme.h"
#include <QDebug>
#include <QHostAddress>
#include <stdlib.h>
#include <qmath.h>

quint32 deviceSerialNo = 264552087;
quint32 password = 1809486432;
QString ip = "172.16.40.105";
quint16 port = 5522;

int* X;
void test(){

QLibrary library("C:/Users/burak/Documents/LibTester_RFID/Includes/_RC_UTIL.dll");
    if (!library.load())
        qDebug() << library.errorString();
    if (library.load())
        qDebug() << "library loaded";

typedef int *(*MyPrototype)(quint32,quint32,quint32,quint16);
    MyPrototype resolvedfunction = (MyPrototype)library.resolve("__Device_Properties");
    if (resolvedfunction) {
      qDebug() << resolvedfunction;
      qDebug() << "resolved";

      quint32 decimalip = iptohex(ip);
      qDebug() << ip;

      X = resolvedfunction(deviceSerialNo,password,decimalip,port);
      qDebug() << X;
          typedef int *(*MyPrototype2)(int*);
              MyPrototype2 resolvedfunction2 = (MyPrototype2)library.resolve("__Show_Error_Message");
              if(resolvedfunction2){
                  qDebug() << resolvedfunction2;
                  qDebug() << "resolved2";

                  resolvedfunction2(X);
              }
    }
    else{
        qDebug() << resolvedfunction;
        qDebug() << "not resolved";
    }
}

quint32 iptohex(QString ipstring){

    quint32 result;
    QString x1,x2,x3,x4;

     x1 = ipstring.split('.').at(0);
    qDebug()<< x1;
     x2 = ipstring.split('.').at(1);
    qDebug()<< x2;
     x3 = ipstring.split('.').at(2);
    qDebug()<< x3;
     x4 = ipstring.split('.').at(3);
    qDebug()<< x4;

    result = qPow(256,3)*x4.toInt() + qPow(256,2)*x3.toInt() + qPow(256,1)*x2.toInt() + qPow(256,0)*x1.toInt();
    qDebug() << result;

    return result;
}
