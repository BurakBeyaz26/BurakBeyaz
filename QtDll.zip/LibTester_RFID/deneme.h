#ifndef DENEME_H
#define DENEME_H

//#include "__DLL_IMPORT.h"
//#include "sysError.h"
//#include "_RC_SDK.h"
#include <QLibrary>

void test();
quint32 iptohex(QString ipstring);

#endif // DENEME_H
